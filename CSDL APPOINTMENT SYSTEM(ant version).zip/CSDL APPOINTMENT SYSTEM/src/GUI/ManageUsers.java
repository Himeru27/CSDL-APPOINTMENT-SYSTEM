
package GUI;



import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;

public class ManageUsers extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(ManageUsers.class.getName());
    private String username;
    private Connection conn;
    
    public ManageUsers() {
        initComponents();
        connectDB();
        refreshTable();
        setupTableListener();
    }
    
    private void connectDB() { 
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); 
            conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/appointmentsystem_db", 
                "root", ""        
            );
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "DB Connection Error: " + e.getMessage());
        }
    } 

    private void refreshTable() {
        DefaultTableModel model = (DefaultTableModel) UsersTable.getModel();
        model.setRowCount(0);

        try {
            String query = "SELECT sd.firstname, sd.middleinitial, sd.lastname, ua.username, c.course_name, ua.password " +
                          "FROM user_account ua " +
                          "JOIN student_details sd ON ua.user_id = sd.user_id " +
                          "JOIN course c ON sd.course_id = c.course_id " +
                          "WHERE ua.username != 'admin'";
            
            PreparedStatement pst = conn.prepareStatement(query);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("firstname"),
                    rs.getString("middleinitial"),
                    rs.getString("lastname"),
                    rs.getString("username"),
                    rs.getString("course_name"),
                    rs.getString("password")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading users: " + e.getMessage());
        }
    }

    private void loadUserToFields(int row) {
        fNameField.setText(UsersTable.getValueAt(row, 0).toString());
        MIField.setText(UsersTable.getValueAt(row, 1).toString());
        lNameField.setText(UsersTable.getValueAt(row, 2).toString());
        IDNumField.setText(UsersTable.getValueAt(row, 3).toString());
        String courseValue = UsersTable.getValueAt(row, 4).toString();
        Course.setSelectedItem(courseValue);
        pass.setText(UsersTable.getValueAt(row, 5).toString());
    }

    private boolean userExists(String idNumber) {
        try (PreparedStatement pst = conn.prepareStatement("SELECT * FROM user_account WHERE username=?")) {
            pst.setString(1, idNumber);
            ResultSet rs = pst.executeQuery();
            return rs.next();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
            return false;
        }
    }

    private void setupTableListener() {
        UsersTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                int row = UsersTable.getSelectedRow();
                if (row >= 0) {
                    loadUserToFields(row);
                }
            }
        });
    }

    private void clearFields() {
        fNameField.setText("");
        MIField.setText("");
        lNameField.setText("");
        IDNumField.setText("");
        Course.setSelectedIndex(0);
        pass.setText("");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        AdminDashboardBTN = new javax.swing.JButton();
        ManageAppointmentBTN = new javax.swing.JButton();
        ManageUsersBTN = new javax.swing.JButton();
        AdminProfileBTN = new javax.swing.JButton();
        LogoutBTN = new javax.swing.JButton();
        ArchiveBTN = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        UsersTable = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        fNameField = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        MIField = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        lNameField = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        IDNumField = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        pass = new javax.swing.JTextField();
        AddBTN = new javax.swing.JButton();
        UPDBTN = new javax.swing.JButton();
        Course = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 102, 51));

        jPanel2.setBackground(new java.awt.Color(0, 153, 51));
        jPanel2.setPreferredSize(new java.awt.Dimension(195, 420));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/APPSYS/Assets/ezgif.com-resize (1).png"))); // NOI18N
        jLabel2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(102, 102, 102), new java.awt.Color(102, 102, 102)));

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("PHINMA COC");

        AdminDashboardBTN.setFont(new java.awt.Font("Yu Gothic UI", 0, 12)); // NOI18N
        AdminDashboardBTN.setText("Dashboard");
        AdminDashboardBTN.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(102, 102, 102), new java.awt.Color(102, 102, 102)));
        AdminDashboardBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AdminDashboardBTNActionPerformed(evt);
            }
        });

        ManageAppointmentBTN.setFont(new java.awt.Font("Yu Gothic UI", 0, 12)); // NOI18N
        ManageAppointmentBTN.setText("Manage Appointments");
        ManageAppointmentBTN.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(102, 102, 102), new java.awt.Color(102, 102, 102)));
        ManageAppointmentBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ManageAppointmentBTNActionPerformed(evt);
            }
        });

        ManageUsersBTN.setFont(new java.awt.Font("Yu Gothic UI", 0, 12)); // NOI18N
        ManageUsersBTN.setText(">> Manage Users <<");
        ManageUsersBTN.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(102, 102, 102), new java.awt.Color(102, 102, 102)));
        ManageUsersBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ManageUsersBTNActionPerformed(evt);
            }
        });

        AdminProfileBTN.setFont(new java.awt.Font("Yu Gothic UI", 0, 12)); // NOI18N
        AdminProfileBTN.setText("Profile");
        AdminProfileBTN.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(102, 102, 102), new java.awt.Color(102, 102, 102)));
        AdminProfileBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AdminProfileBTNActionPerformed(evt);
            }
        });

        LogoutBTN.setBackground(new java.awt.Color(255, 51, 51));
        LogoutBTN.setFont(new java.awt.Font("Yu Gothic UI", 1, 14)); // NOI18N
        LogoutBTN.setForeground(new java.awt.Color(255, 255, 255));
        LogoutBTN.setText("Logout");
        LogoutBTN.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(102, 102, 102), new java.awt.Color(102, 102, 102)));
        LogoutBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LogoutBTNActionPerformed(evt);
            }
        });

        ArchiveBTN.setText("Archives");
        ArchiveBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ArchiveBTNActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("v3.0");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(26, 26, 26)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(AdminDashboardBTN, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(ManageAppointmentBTN, javax.swing.GroupLayout.DEFAULT_SIZE, 141, Short.MAX_VALUE)
                                        .addComponent(ManageUsersBTN, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel2))))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(59, 59, 59)
                                .addComponent(LogoutBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 2, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(AdminProfileBTN, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ArchiveBTN, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(26, 26, 26))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(AdminDashboardBTN)
                .addGap(18, 18, 18)
                .addComponent(ManageAppointmentBTN)
                .addGap(17, 17, 17)
                .addComponent(ManageUsersBTN)
                .addGap(18, 18, 18)
                .addComponent(AdminProfileBTN)
                .addGap(18, 18, 18)
                .addComponent(ArchiveBTN)
                .addGap(29, 29, 29)
                .addComponent(LogoutBTN)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel10)
                .addContainerGap())
        );

        UsersTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "First Name", "M.I", "Last Name", "ID #", "Course", "Password"
            }
        ));
        jScrollPane1.setViewportView(UsersTable);

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel4.setText("First Name:");

        fNameField.setText("\n");
        fNameField.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153)));

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel5.setText("M.I.:");

        MIField.setText("\n");
        MIField.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153)));

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel6.setText("Last Name:");

        lNameField.setText("\n");
        lNameField.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153)));

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel7.setText("ID Number:");

        IDNumField.setText("\n");
        IDNumField.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153)));

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel8.setText("Course:");

        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel9.setText("Password:");

        pass.setText("\n");
        pass.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153)));

        AddBTN.setBackground(new java.awt.Color(102, 255, 102));
        AddBTN.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        AddBTN.setForeground(new java.awt.Color(255, 255, 255));
        AddBTN.setText("Add");
        AddBTN.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153)));
        AddBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddBTNActionPerformed(evt);
            }
        });

        UPDBTN.setBackground(new java.awt.Color(102, 255, 102));
        UPDBTN.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        UPDBTN.setForeground(new java.awt.Color(255, 255, 255));
        UPDBTN.setText("Update");
        UPDBTN.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153)));
        UPDBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UPDBTNActionPerformed(evt);
            }
        });

        Course.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "BS Information Technology", "Engineering", "Computer Science", "BS Accountancy", "BS Psychology", "BS Architechture", "Humanities" }));
        Course.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CourseActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(MIField)
                    .addComponent(lNameField)
                    .addComponent(fNameField, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabel4)
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel6)
                                .addComponent(jLabel7)
                                .addComponent(jLabel8)
                                .addComponent(jLabel9)
                                .addComponent(AddBTN, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(UPDBTN, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE))
                            .addComponent(Course, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(pass, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(IDNumField))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 368, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(fNameField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(MIField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lNameField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(IDNumField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Course, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pass, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(AddBTN)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(UPDBTN)
                .addContainerGap(31, Short.MAX_VALUE))
            .addComponent(jScrollPane1)
        );

        jLabel1.setFont(new java.awt.Font("Yu Gothic", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("CSDL APPOINTMENT SYSTEM");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(139, 139, 139)
                        .addComponent(jLabel1)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 487, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(22, 22, 22))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void AdminDashboardBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AdminDashboardBTNActionPerformed
        // TODO add your handling code here:

        AdminDashboard ADash = new AdminDashboard();
        ADash.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_AdminDashboardBTNActionPerformed

    private void ManageAppointmentBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ManageAppointmentBTNActionPerformed
        // TODO add your handling code here:

        ManageAppointments MAppoint = new ManageAppointments();
        MAppoint.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_ManageAppointmentBTNActionPerformed

    private void ManageUsersBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ManageUsersBTNActionPerformed
        // TODO add your handling code here:

        ManageUsers Manage = new ManageUsers();
        Manage.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_ManageUsersBTNActionPerformed

    private void AdminProfileBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AdminProfileBTNActionPerformed
        // TODO add your handling code here:
        
        AdminProfile AProf = new AdminProfile();
        AProf.setVisible(true);
        this.dispose();

    }//GEN-LAST:event_AdminProfileBTNActionPerformed

    private void AddBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddBTNActionPerformed
        // TODO add your handling code here:
        
        String fname = fNameField.getText().trim();
        String mi = MIField.getText().trim();
        String lname = lNameField.getText().trim();
        String id = IDNumField.getText().trim();
        String courseName = (String) Course.getSelectedItem();
        String pw = pass.getText().trim();

        if (fname.isEmpty() || id.isEmpty() || pw.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill out all required fields.");
            return;
        }

        if (userExists(id)) {
            JOptionPane.showMessageDialog(this, "User ID already exists!");
            return;
        }

        try {
            // Start transaction
            conn.setAutoCommit(false);
            
            // Insert into user_account
            String userSql = "INSERT INTO user_account (username, password, role_id) VALUES (?, ?, (SELECT role_id FROM role WHERE role_name = 'Student'))";
            PreparedStatement userStmt = conn.prepareStatement(userSql, Statement.RETURN_GENERATED_KEYS);
            userStmt.setString(1, id);
            userStmt.setString(2, pw);
            userStmt.executeUpdate();
            
            // Get generated user_id
            ResultSet rs = userStmt.getGeneratedKeys();
            int userId = 0;
            if (rs.next()) {
                userId = rs.getInt(1);
            }
            
            // Insert into student_details
            String detailsSql = "INSERT INTO student_details (user_id, firstname, middleinitial, lastname, course_id) VALUES (?, ?, ?, ?, (SELECT course_id FROM course WHERE course_name = ?))";
            PreparedStatement detailsStmt = conn.prepareStatement(detailsSql);
            detailsStmt.setInt(1, userId);
            detailsStmt.setString(2, fname);
            detailsStmt.setString(3, mi);
            detailsStmt.setString(4, lname);
            detailsStmt.setString(5, courseName);
            detailsStmt.executeUpdate();
            
            conn.commit();
            refreshTable();
            clearFields();
            JOptionPane.showMessageDialog(this, "User added successfully!");
            
        } catch (SQLException e) {
            try {
                conn.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        } finally {
            try {
                conn.setAutoCommit(true);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }//GEN-LAST:event_AddBTNActionPerformed

    private void UPDBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UPDBTNActionPerformed
        // TODO add your handling code here:
        
        int row = UsersTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select a user to update.");
            return;
        }

        String oldId = UsersTable.getValueAt(row, 3).toString();
        String newId = IDNumField.getText().trim();
        
        if (!oldId.equals(newId) && userExists(newId)) {
            JOptionPane.showMessageDialog(this, "This ID number already exists!");
            return;
        }

        String fname = fNameField.getText().trim();
        String mi = MIField.getText().trim();
        String lname = lNameField.getText().trim();
        String courseName = (String) Course.getSelectedItem();
        String pw = pass.getText().trim();

        if (fname.isEmpty() || newId.isEmpty() || pw.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill out all required fields.");
            return;
        }

        try {
            conn.setAutoCommit(false);
            
            // Update user_account
            String userSql = "UPDATE user_account SET username = ?, password = ? WHERE username = ?";
            PreparedStatement userStmt = conn.prepareStatement(userSql);
            userStmt.setString(1, newId);
            userStmt.setString(2, pw);
            userStmt.setString(3, oldId);
            userStmt.executeUpdate();
            
            // Update student_details
            String detailsSql = "UPDATE student_details sd " +
                               "JOIN user_account ua ON sd.user_id = ua.user_id " +
                               "SET sd.firstname = ?, sd.middleinitial = ?, sd.lastname = ?, " +
                               "sd.course_id = (SELECT course_id FROM course WHERE course_name = ?) " +
                               "WHERE ua.username = ?";
            PreparedStatement detailsStmt = conn.prepareStatement(detailsSql);
            detailsStmt.setString(1, fname);
            detailsStmt.setString(2, mi);
            detailsStmt.setString(3, lname);
            detailsStmt.setString(4, courseName);
            detailsStmt.setString(5, newId);
            detailsStmt.executeUpdate();
            
            conn.commit();
            refreshTable();
            clearFields();
            JOptionPane.showMessageDialog(this, "User updated successfully!");
            
        } catch (SQLException e) {
            try {
                conn.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        } finally {
            try {
                conn.setAutoCommit(true);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(() -> new ManageUsers().setVisible(true));
    }//GEN-LAST:event_UPDBTNActionPerformed

    private void LogoutBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LogoutBTNActionPerformed
        // TODO add your handling code here:
        
        int response = JOptionPane.showConfirmDialog(this, 
            "Are you sure you want to logout?", 
            "Confirm Logout", 
            JOptionPane.YES_NO_OPTION);
        
        if (response == JOptionPane.YES_OPTION) {
            LoginPortal login = new LoginPortal();
            login.setVisible(true);
            this.dispose();
        }
    }//GEN-LAST:event_LogoutBTNActionPerformed

    private void CourseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CourseActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CourseActionPerformed

    private void ArchiveBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ArchiveBTNActionPerformed
        // TODO add your handling code here:
        
        ArchiveManager ArcMan = new ArchiveManager();
        ArcMan.setVisible(true);
        this.dispose();
        
    }//GEN-LAST:event_ArchiveBTNActionPerformed



    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddBTN;
    private javax.swing.JButton AdminDashboardBTN;
    private javax.swing.JButton AdminProfileBTN;
    private javax.swing.JButton ArchiveBTN;
    private javax.swing.JComboBox<String> Course;
    private javax.swing.JTextField IDNumField;
    private javax.swing.JButton LogoutBTN;
    private javax.swing.JTextField MIField;
    private javax.swing.JButton ManageAppointmentBTN;
    private javax.swing.JButton ManageUsersBTN;
    private javax.swing.JButton UPDBTN;
    private javax.swing.JTable UsersTable;
    private javax.swing.JTextField fNameField;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField lNameField;
    private javax.swing.JTextField pass;
    // End of variables declaration//GEN-END:variables
}
