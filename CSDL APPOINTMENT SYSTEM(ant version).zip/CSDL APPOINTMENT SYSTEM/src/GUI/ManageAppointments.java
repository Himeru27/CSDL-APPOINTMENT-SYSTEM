
package GUI;

import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import javax.swing.table.TableColumnModel;

public class ManageAppointments extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(ManageAppointments.class.getName());
    
    private String username;
    private Connection conn;
    
    public ManageAppointments() {
        initComponents();
        connectDB();
        loadAppointments();
        setupTableColors();
        setupTableColumns();
    }
    
    private void connectDB() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/appointmentsystem_db", 
                "root", "");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Database Error: " + e.getMessage());
        }
    }
    
    private void setupTableColumns() {
        TableColumnModel columnModel = ManageAppointmentTb.getColumnModel();
        columnModel.getColumn(0).setPreferredWidth(120); 
        columnModel.getColumn(1).setPreferredWidth(50); 
        columnModel.getColumn(2).setPreferredWidth(90); 
        columnModel.getColumn(3).setPreferredWidth(90);
        columnModel.getColumn(4).setPreferredWidth(90);
        ManageAppointmentTb.setRowHeight(60);
    }
    
private void loadAppointments() {
    try {
        String query = "SELECT a.appointment_id, ua.username, c.course_name, " +
                      "DATE(a.appointment_date) as appointment_date, " +
                      "at.appointment_name, s.status_name " +
                      "FROM appointment a " +
                      "JOIN user_account ua ON a.user_id = ua.user_id " +
                      "JOIN course c ON a.course_id = c.course_id " +
                      "JOIN appointment_type at ON a.type_id = at.type_id " +
                      "JOIN status s ON a.status_id = s.status_id " +
                      "WHERE a.is_archived = FALSE " +  // ONLY SHOW NON-ARCHIVED
                      "ORDER BY a.created_at DESC";
        
        PreparedStatement pst = conn.prepareStatement(query);
        ResultSet rs = pst.executeQuery();

        DefaultTableModel model = (DefaultTableModel) ManageAppointmentTb.getModel();
        model.setRowCount(0);

        while (rs.next()) {
            model.addRow(new Object[]{
                rs.getInt("appointment_id"),
                rs.getString("username"), 
                rs.getString("appointment_date"),
                rs.getString("appointment_name"),
                rs.getString("status_name")
            });
        }
        ManageAppointmentTb.setModel(model);

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error loading appointments: " + e.getMessage());
    }
}
    
    private void setupTableColors() {
        ManageAppointmentTb.getColumnModel().getColumn(4).setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
        
                if (value != null) {
                    String status = value.toString();
                    c.setBackground(status.equals("Approved") ? Color.GREEN : 
                    status.equals("Denied") ? Color.RED : Color.WHITE);
                    c.setForeground(Color.BLACK);
                }
                return c;
            }
        });
    }
    
    private void sendMessageToUser(String username, String messageContent) {
        String sql = "INSERT INTO messages (sender_id, receiver_id, content) " +
            "VALUES ((SELECT user_id FROM user_account WHERE username = 'admin'), " +
            "(SELECT user_id FROM user_account WHERE username = ?), ?)";

        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, username);
            pst.setString(2, messageContent);
            pst.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error sending message: " + e.getMessage());
        }
    }
    
private void archiveSelectedAppointment() {
    int row = ManageAppointmentTb.getSelectedRow();
    if (row == -1) {
        JOptionPane.showMessageDialog(this, "Please select an appointment to archive.");
        return;
    }
    
    int appointmentId = (int) ManageAppointmentTb.getValueAt(row, 0);
    String username = (String) ManageAppointmentTb.getValueAt(row, 1);
    String appointmentType = (String) ManageAppointmentTb.getValueAt(row, 3);
    
    String reason = JOptionPane.showInputDialog(this, 
        "Enter reason for archiving appointment for " + username + ":");
    
    if (reason == null || reason.trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Archive reason is required.");
        return;
    }
    
    int confirm = JOptionPane.showConfirmDialog(this,
        "Archive this appointment?\n\nUser: " + username + 
        "\nType: " + appointmentType + "\nReason: " + reason,
        "Confirm Archive",
        JOptionPane.YES_NO_OPTION);
    
    if (confirm == JOptionPane.YES_OPTION) {
        try {
            String sql = "UPDATE appointment SET is_archived = TRUE, archive_reason = ?, archived_at = NOW() " +
                        "WHERE appointment_id = ?";
            
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, reason);
            pst.setInt(2, appointmentId);
            pst.executeUpdate();
            
            JOptionPane.showMessageDialog(this, "Appointment archived successfully!");
            loadAppointments(); // This will refresh and the archived appointment will vanish
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error archiving appointment: " + e.getMessage());
        }
    }
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        AdminDashboardBTN = new javax.swing.JButton();
        ManageAppointmentBTN = new javax.swing.JButton();
        ManageUsersBTN = new javax.swing.JButton();
        AdminProfileBTN = new javax.swing.JButton();
        LogoutBTN = new javax.swing.JButton();
        ArchiveBTN1 = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        ManageAppointmentTb = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        DenyBTN = new javax.swing.JButton();
        ApproveBTN = new javax.swing.JButton();
        ArchiveBTN = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 102, 51));

        jPanel2.setBackground(new java.awt.Color(0, 153, 51));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/APPSYS/Assets/ezgif.com-resize (1).png"))); // NOI18N
        jLabel2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(102, 102, 102), new java.awt.Color(102, 102, 102)));

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("PHINMA COC");

        AdminDashboardBTN.setFont(new java.awt.Font("Yu Gothic UI", 0, 12)); // NOI18N
        AdminDashboardBTN.setText("Dashboard");
        AdminDashboardBTN.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(102, 102, 102), new java.awt.Color(102, 102, 102)));
        AdminDashboardBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AdminDashboardBTNActionPerformed(evt);
            }
        });

        ManageAppointmentBTN.setFont(new java.awt.Font("Yu Gothic UI", 0, 12)); // NOI18N
        ManageAppointmentBTN.setText(">Manage Appointments<");
        ManageAppointmentBTN.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(102, 102, 102), new java.awt.Color(102, 102, 102)));
        ManageAppointmentBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ManageAppointmentBTNActionPerformed(evt);
            }
        });

        ManageUsersBTN.setFont(new java.awt.Font("Yu Gothic UI", 0, 12)); // NOI18N
        ManageUsersBTN.setText("Manage Users");
        ManageUsersBTN.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(102, 102, 102), new java.awt.Color(102, 102, 102)));
        ManageUsersBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ManageUsersBTNActionPerformed(evt);
            }
        });

        AdminProfileBTN.setFont(new java.awt.Font("Yu Gothic UI", 0, 12)); // NOI18N
        AdminProfileBTN.setText("Profile");
        AdminProfileBTN.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(102, 102, 102), new java.awt.Color(102, 102, 102)));
        AdminProfileBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AdminProfileBTNActionPerformed(evt);
            }
        });

        LogoutBTN.setBackground(new java.awt.Color(255, 51, 51));
        LogoutBTN.setFont(new java.awt.Font("Yu Gothic UI", 1, 14)); // NOI18N
        LogoutBTN.setForeground(new java.awt.Color(255, 255, 255));
        LogoutBTN.setText("Logout");
        LogoutBTN.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(102, 102, 102), new java.awt.Color(102, 102, 102)));
        LogoutBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LogoutBTNActionPerformed(evt);
            }
        });

        ArchiveBTN1.setText("Archives");
        ArchiveBTN1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ArchiveBTN1ActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("v3.0");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(26, 26, 26)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(AdminDashboardBTN, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(ManageAppointmentBTN, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(ManageUsersBTN, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel2))))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(59, 59, 59)
                                .addComponent(LogoutBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ArchiveBTN1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(AdminProfileBTN, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(26, 26, 26))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(AdminDashboardBTN)
                .addGap(18, 18, 18)
                .addComponent(ManageAppointmentBTN)
                .addGap(17, 17, 17)
                .addComponent(ManageUsersBTN)
                .addGap(18, 18, 18)
                .addComponent(AdminProfileBTN)
                .addGap(18, 18, 18)
                .addComponent(ArchiveBTN1)
                .addGap(29, 29, 29)
                .addComponent(LogoutBTN)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 47, Short.MAX_VALUE)
                .addComponent(jLabel10)
                .addContainerGap())
        );

        jPanel3.setBackground(new java.awt.Color(204, 204, 204));

        ManageAppointmentTb.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Appointment ID", "User ID", "Date", "Type", "Status"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(ManageAppointmentTb);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 506, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 417, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jLabel1.setFont(new java.awt.Font("Yu Gothic", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("CSDL APPOINTMENT SYSTEM");

        DenyBTN.setBackground(new java.awt.Color(255, 102, 102));
        DenyBTN.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        DenyBTN.setForeground(new java.awt.Color(255, 255, 255));
        DenyBTN.setText("Deny");
        DenyBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DenyBTNActionPerformed(evt);
            }
        });

        ApproveBTN.setBackground(new java.awt.Color(102, 255, 102));
        ApproveBTN.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        ApproveBTN.setForeground(new java.awt.Color(255, 255, 255));
        ApproveBTN.setText("Approve");
        ApproveBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ApproveBTNActionPerformed(evt);
            }
        });

        ArchiveBTN.setBackground(new java.awt.Color(255, 204, 0));
        ArchiveBTN.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        ArchiveBTN.setForeground(new java.awt.Color(255, 255, 255));
        ArchiveBTN.setText("Archive");
        ArchiveBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ArchiveBTNActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(ApproveBTN, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(DenyBTN, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ArchiveBTN, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(102, 102, 102)
                        .addComponent(jLabel1)))
                .addContainerGap(12, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(ArchiveBTN)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(DenyBTN)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(ApproveBTN))
                            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(10, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void AdminDashboardBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AdminDashboardBTNActionPerformed
        // TODO add your handling code here:

        AdminDashboard ADash = new AdminDashboard();
        ADash.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_AdminDashboardBTNActionPerformed

    private void ManageAppointmentBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ManageAppointmentBTNActionPerformed
        // TODO add your handling code here:

        ManageAppointments MAppoint = new ManageAppointments();
        MAppoint.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_ManageAppointmentBTNActionPerformed

    private void ManageUsersBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ManageUsersBTNActionPerformed
        // TODO add your handling code here:

        ManageUsers Manage = new ManageUsers();
        Manage.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_ManageUsersBTNActionPerformed

    private void AdminProfileBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AdminProfileBTNActionPerformed
        // TODO add your handling code here:

        AdminProfile AProf = new AdminProfile();
        AProf.setVisible(true);
        this.dispose();
        
    }//GEN-LAST:event_AdminProfileBTNActionPerformed

    private void DenyBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DenyBTNActionPerformed
        // TODO add your handling code here:
        
        int row = ManageAppointmentTb.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select an appointment to deny.");
            return;
        }

        int appointmentId = (int) ManageAppointmentTb.getValueAt(row, 0);
        String username = (String) ManageAppointmentTb.getValueAt(row, 1);
        String appointmentType = (String) ManageAppointmentTb.getValueAt(row, 3);
        String reason = JOptionPane.showInputDialog(this, "Enter reason for denial:");
        
        if (reason == null || reason.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Reason is required for denial.");
            return;
        }
        
        try {
            String sql = "UPDATE appointment SET status_id = (SELECT status_id FROM status WHERE status_name = 'Denied') " +
                        "WHERE appointment_id = ?";
            
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, appointmentId);
            ps.executeUpdate();

            String messageContent = "Your " + appointmentType + " appointment has been DENIED. Reason: " + reason;
            sendMessageToUser(username, messageContent);
            
            JOptionPane.showMessageDialog(this, "Appointment denied and user notified!");
            loadAppointments();
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }//GEN-LAST:event_DenyBTNActionPerformed

    private void ApproveBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ApproveBTNActionPerformed
        // TODO add your handling code here:
        
        int row = ManageAppointmentTb.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select an appointment to approve.");
            return;
        }

        int appointmentId = (int) ManageAppointmentTb.getValueAt(row, 0);
        String username = (String) ManageAppointmentTb.getValueAt(row, 1);
        String appointmentType = (String) ManageAppointmentTb.getValueAt(row, 3);
        
        try {
            String sql = "UPDATE appointment SET status_id = (SELECT status_id FROM status WHERE status_name = 'Approved') " +
                        "WHERE appointment_id = ?";
            
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, appointmentId);
            ps.executeUpdate();

            String messageContent = "Your " + appointmentType + " appointment has been APPROVED! Please arrive on time of Schedule.";
            sendMessageToUser(username, messageContent);
            
            JOptionPane.showMessageDialog(this, "Appointment approved and user notified!");
            loadAppointments();
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }//GEN-LAST:event_ApproveBTNActionPerformed

    private void LogoutBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LogoutBTNActionPerformed
        // TODO add your handling code here:
        
        int response = JOptionPane.showConfirmDialog(this, 
            "Are you sure you want to logout?", 
            "Confirm Logout", 
            JOptionPane.YES_NO_OPTION);
        
        if (response == JOptionPane.YES_OPTION) {
            LoginPortal login = new LoginPortal();
            login.setVisible(true);
            this.dispose();
        }
    }//GEN-LAST:event_LogoutBTNActionPerformed

    private void ArchiveBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ArchiveBTNActionPerformed
        // TODO add your handling code here:
        
        archiveSelectedAppointment();
    }//GEN-LAST:event_ArchiveBTNActionPerformed

    private void ArchiveBTN1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ArchiveBTN1ActionPerformed
        // TODO add your handling code here:
        
        ArchiveManager ArcMan = new ArchiveManager();
        ArcMan.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_ArchiveBTN1ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and dispAdminDashboardBTN */
        java.awt.EventQueue.invokeLater(() -> new ManageAppointments().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AdminDashboardBTN;
    private javax.swing.JButton AdminProfileBTN;
    private javax.swing.JButton ApproveBTN;
    private javax.swing.JButton ArchiveBTN;
    private javax.swing.JButton ArchiveBTN1;
    private javax.swing.JButton DenyBTN;
    private javax.swing.JButton LogoutBTN;
    private javax.swing.JButton ManageAppointmentBTN;
    private javax.swing.JTable ManageAppointmentTb;
    private javax.swing.JButton ManageUsersBTN;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
