package GUI;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.logging.Logger;

public class ArchiveManager extends javax.swing.JFrame {
    
    private static final Logger logger = Logger.getLogger(ArchiveManager.class.getName());
    private Connection conn;
    
    public ArchiveManager() {
        initComponents();
        connectDB();
        loadArchivedAppointments();
    }
    
    private void connectDB() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/appointmentsystem_db", 
                "root", "");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Database Error: " + e.getMessage());
        }
    }
    
private void loadArchivedAppointments() {
    DefaultTableModel model = (DefaultTableModel) ArchiveTB.getModel();
    model.setRowCount(0);
    
    try {
        String query = "SELECT a.appointment_id, ua.username, c.course_name, " +
                      "a.appointment_date, at.appointment_name, a.archive_reason " +
                      "FROM appointment a " +
                      "JOIN user_account ua ON a.user_id = ua.user_id " +
                      "JOIN course c ON a.course_id = c.course_id " +
                      "JOIN appointment_type at ON a.type_id = at.type_id " +
                      "WHERE a.is_archived = TRUE " +  // ONLY SHOW ARCHIVED
                      "ORDER BY a.archived_at DESC";
        
        PreparedStatement pst = conn.prepareStatement(query);
        ResultSet rs = pst.executeQuery();
        
        while (rs.next()) {
            model.addRow(new Object[]{
                rs.getInt("appointment_id"),
                rs.getString("username"),
                rs.getString("course_name"),
                rs.getString("appointment_date"),
                rs.getString("appointment_name"),
                rs.getString("archive_reason")
            });
        }
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error loading archives: " + e.getMessage());
    }
}
    
    private void archiveSelectedAppointment() {
        // This method would be called from ManageAppointments
        // Implementation below...
    }
    
    private void restoreSelectedAppointment() {
        int row = ArchiveTB.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select an appointment to restore.");
            return;
        }
        
        int appointmentId = (int) ArchiveTB.getValueAt(row, 0);
        
        try {
            String sql = "UPDATE appointment SET is_archived = FALSE, archive_reason = NULL, archived_at = NULL " +
                        "WHERE appointment_id = ?";
            
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setInt(1, appointmentId);
            pst.executeUpdate();
            
            JOptionPane.showMessageDialog(this, "Appointment restored successfully!");
            loadArchivedAppointments();
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error restoring appointment: " + e.getMessage());
        }
    }
    
    private void deleteSelectedAppointment() {
        int row = ArchiveTB.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select an appointment to delete.");
            return;
        }
        
        int appointmentId = (int) ArchiveTB.getValueAt(row, 0);
        
        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to permanently delete this appointment?",
            "Confirm Delete",
            JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                String sql = "DELETE FROM appointment WHERE appointment_id = ?";
                PreparedStatement pst = conn.prepareStatement(sql);
                pst.setInt(1, appointmentId);
                pst.executeUpdate();
                
                JOptionPane.showMessageDialog(this, "Appointment permanently deleted!");
                loadArchivedAppointments();
                
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error deleting appointment: " + e.getMessage());
            }
        }
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel5 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        AdminDashboardBTN2 = new javax.swing.JButton();
        ManageAppointmentBTN2 = new javax.swing.JButton();
        ManageUsersBTN2 = new javax.swing.JButton();
        AdminProfileBTN2 = new javax.swing.JButton();
        LogoutBTN2 = new javax.swing.JButton();
        ArchiveBTN2 = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        ArchiveTB = new javax.swing.JTable();
        jLabel8 = new javax.swing.JLabel();
        RetrieveBTN = new javax.swing.JButton();
        HardDeleteBTN = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel5.setBackground(new java.awt.Color(0, 102, 51));

        jPanel6.setBackground(new java.awt.Color(0, 153, 51));
        jPanel6.setPreferredSize(new java.awt.Dimension(195, 420));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/APPSYS/Assets/ezgif.com-resize (1).png"))); // NOI18N
        jLabel6.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(102, 102, 102), new java.awt.Color(102, 102, 102)));

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("PHINMA COC");

        AdminDashboardBTN2.setFont(new java.awt.Font("Yu Gothic UI", 0, 12)); // NOI18N
        AdminDashboardBTN2.setText("Dashboard");
        AdminDashboardBTN2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(102, 102, 102), new java.awt.Color(102, 102, 102)));
        AdminDashboardBTN2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AdminDashboardBTN2ActionPerformed(evt);
            }
        });

        ManageAppointmentBTN2.setFont(new java.awt.Font("Yu Gothic UI", 0, 12)); // NOI18N
        ManageAppointmentBTN2.setText("Manage Appointments");
        ManageAppointmentBTN2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(102, 102, 102), new java.awt.Color(102, 102, 102)));
        ManageAppointmentBTN2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ManageAppointmentBTN2ActionPerformed(evt);
            }
        });

        ManageUsersBTN2.setFont(new java.awt.Font("Yu Gothic UI", 0, 12)); // NOI18N
        ManageUsersBTN2.setText("Manage Users");
        ManageUsersBTN2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(102, 102, 102), new java.awt.Color(102, 102, 102)));
        ManageUsersBTN2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ManageUsersBTN2ActionPerformed(evt);
            }
        });

        AdminProfileBTN2.setFont(new java.awt.Font("Yu Gothic UI", 0, 12)); // NOI18N
        AdminProfileBTN2.setText("Profile");
        AdminProfileBTN2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(102, 102, 102), new java.awt.Color(102, 102, 102)));
        AdminProfileBTN2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AdminProfileBTN2ActionPerformed(evt);
            }
        });

        LogoutBTN2.setBackground(new java.awt.Color(255, 51, 51));
        LogoutBTN2.setFont(new java.awt.Font("Yu Gothic UI", 1, 14)); // NOI18N
        LogoutBTN2.setForeground(new java.awt.Color(255, 255, 255));
        LogoutBTN2.setText("Logout");
        LogoutBTN2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(102, 102, 102), new java.awt.Color(102, 102, 102)));
        LogoutBTN2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LogoutBTN2ActionPerformed(evt);
            }
        });

        ArchiveBTN2.setText(">> Archives <<");
        ArchiveBTN2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ArchiveBTN2ActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("v3.0");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGap(26, 26, 26)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel6Layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(AdminDashboardBTN2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(ManageAppointmentBTN2, javax.swing.GroupLayout.DEFAULT_SIZE, 141, Short.MAX_VALUE)
                                        .addComponent(ManageUsersBTN2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel6))))
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGap(59, 59, 59)
                                .addComponent(LogoutBTN2, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 2, Short.MAX_VALUE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(AdminProfileBTN2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ArchiveBTN2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(26, 26, 26))
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7)
                .addGap(18, 18, 18)
                .addComponent(AdminDashboardBTN2)
                .addGap(18, 18, 18)
                .addComponent(ManageAppointmentBTN2)
                .addGap(17, 17, 17)
                .addComponent(ManageUsersBTN2)
                .addGap(18, 18, 18)
                .addComponent(AdminProfileBTN2)
                .addGap(18, 18, 18)
                .addComponent(ArchiveBTN2)
                .addGap(29, 29, 29)
                .addComponent(LogoutBTN2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel10))
        );

        ArchiveTB.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "ID #", "Student Full Name", "Course", "Appointment Type", "Date of Appointment", "Reason for archive", "Archive"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Boolean.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(ArchiveTB);

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel8.setText("Archive Appointments");

        RetrieveBTN.setBackground(new java.awt.Color(51, 204, 0));
        RetrieveBTN.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        RetrieveBTN.setForeground(new java.awt.Color(255, 255, 255));
        RetrieveBTN.setText("Retrieve");
        RetrieveBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RetrieveBTNActionPerformed(evt);
            }
        });

        HardDeleteBTN.setBackground(new java.awt.Color(204, 0, 0));
        HardDeleteBTN.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        HardDeleteBTN.setForeground(new java.awt.Color(255, 255, 255));
        HardDeleteBTN.setText("Hard Delete");
        HardDeleteBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HardDeleteBTNActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(267, 267, 267)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 92, Short.MAX_VALUE)
                .addComponent(RetrieveBTN)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(HardDeleteBTN)
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addGap(0, 8, Short.MAX_VALUE)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(RetrieveBTN)
                    .addComponent(HardDeleteBTN))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 416, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jLabel1.setFont(new java.awt.Font("Yu Gothic", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("CSDL APPOINTMENT SYSTEM");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(170, 170, 170)
                        .addComponent(jLabel1)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, 491, Short.MAX_VALUE)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(22, 22, 22))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, 508, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void AdminDashboardBTN2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AdminDashboardBTN2ActionPerformed
        // TODO add your handling code here:

        AdminDashboard ADash = new AdminDashboard();
        ADash.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_AdminDashboardBTN2ActionPerformed

    private void ManageAppointmentBTN2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ManageAppointmentBTN2ActionPerformed
        // TODO add your handling code here:

        ManageAppointments MAppoint = new ManageAppointments();
        MAppoint.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_ManageAppointmentBTN2ActionPerformed

    private void ManageUsersBTN2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ManageUsersBTN2ActionPerformed
        // TODO add your handling code here:

        ManageUsers Manage = new ManageUsers();
        Manage.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_ManageUsersBTN2ActionPerformed

    private void AdminProfileBTN2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AdminProfileBTN2ActionPerformed
        // TODO add your handling code here:

        AdminProfile AProf = new AdminProfile();
        AProf.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_AdminProfileBTN2ActionPerformed

    private void LogoutBTN2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LogoutBTN2ActionPerformed
        // TODO add your handling code here:

        int response = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to logout?",
            "Confirm Logout",
            JOptionPane.YES_NO_OPTION);

        if (response == JOptionPane.YES_OPTION) {
            LoginPortal login = new LoginPortal();
            login.setVisible(true);
            this.dispose();
        }
    }//GEN-LAST:event_LogoutBTN2ActionPerformed

    private void ArchiveBTN2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ArchiveBTN2ActionPerformed
        // TODO add your handling code here:
        ArchiveManager ArcMan = new ArchiveManager();
        ArcMan.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_ArchiveBTN2ActionPerformed

    private void RetrieveBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RetrieveBTNActionPerformed
        // TODO add your handling code here:
        
        restoreSelectedAppointment();
    }//GEN-LAST:event_RetrieveBTNActionPerformed

    private void HardDeleteBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HardDeleteBTNActionPerformed
        // TODO add your handling code here:
        deleteSelectedAppointment();
    }//GEN-LAST:event_HardDeleteBTNActionPerformed


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new ArchiveManager().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AdminDashboardBTN;
    private javax.swing.JButton AdminDashboardBTN1;
    private javax.swing.JButton AdminDashboardBTN2;
    private javax.swing.JButton AdminProfileBTN;
    private javax.swing.JButton AdminProfileBTN1;
    private javax.swing.JButton AdminProfileBTN2;
    private javax.swing.JButton ArchiveBTN;
    private javax.swing.JButton ArchiveBTN1;
    private javax.swing.JButton ArchiveBTN2;
    private javax.swing.JTable ArchiveTB;
    private javax.swing.JButton HardDeleteBTN;
    private javax.swing.JButton LogoutBTN;
    private javax.swing.JButton LogoutBTN1;
    private javax.swing.JButton LogoutBTN2;
    private javax.swing.JButton ManageAppointmentBTN;
    private javax.swing.JButton ManageAppointmentBTN1;
    private javax.swing.JButton ManageAppointmentBTN2;
    private javax.swing.JButton ManageUsersBTN;
    private javax.swing.JButton ManageUsersBTN1;
    private javax.swing.JButton ManageUsersBTN2;
    private javax.swing.JButton RetrieveBTN;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
