
package backend;

public class User {
    private int userId;
    private String username;
    private String password;
    private String firstName;
    private String middleInitial;
    private String lastName;
    private String course;
    private String role;
    

    public User(int userId, String username, String firstName, String lastName, String role) {
        this.userId = userId;
        this.username = username;
        this.firstName = firstName;
        this.lastName = lastName;
        this.role = role;
    }
    
    public int getUserId() { return userId; }
    public String getUsername() { return username; }
    public String getFullName() { return firstName + " " + lastName; }
    public String getRole() { return role; }
}